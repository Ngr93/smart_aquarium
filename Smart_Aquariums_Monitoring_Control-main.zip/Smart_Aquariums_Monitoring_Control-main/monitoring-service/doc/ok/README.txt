Run:
  python main.py

Sub:
  aquarium/+/sensors/agg
Pub:
  aquarium/<device_id>/alerts
  aquarium/<device_id>/commands/water_pump
